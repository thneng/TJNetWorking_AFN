//
//  KRParentAvarModle.m
//  网络封装Demo
//
//  Created by kairu on 16/9/9.
//  Copyright © 2016年 kairu. All rights reserved.
//

#import "KRParentAvarModle.h"

@implementation KRParentAvarModle
- (void)dealloc {
    
    NSLog(@"KRParentAvarModle挂了");
}
@end
