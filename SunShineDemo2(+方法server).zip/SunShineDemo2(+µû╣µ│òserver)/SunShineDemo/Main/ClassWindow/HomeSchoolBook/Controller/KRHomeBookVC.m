//
//  ViewController.m
//  网络封装Demo
//
//  Created by kairu on 16/8/25.
//  Copyright © 2016年 kairu. All rights reserved.
//

#import "KRHomeBookVC.h"
#import "TJHomeBookSerVer.h"

@interface KRHomeBookVC ()

@end

@implementation KRHomeBookVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    /// 设置网络请求.
    [self setRequest];
}


/**
 *  设置网络请求.
 */
- (void)setRequest {
 
    // 类方法请求.
    [TJHomeBookSerVer setBlockWithSuccessBlock:^(id returnValue) {
        NSLog(@"%@",returnValue);
    } messageBlock:^(id returnValue) {
        NSLog(@"%@",returnValue);
    } failureBlock:^(id returnValue) {
        NSLog(@"%@",returnValue);
    }];

    // 类方法请求.
    [TJHomeBookSerVer requestForStudentListWithPage:@"1"];
    
}

- (void)dealloc {

    NSLog(@"KRHomeBookVC挂了");
}

@end
