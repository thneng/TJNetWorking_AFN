//
//  TJRequestModel.m
//  网络封装Demo
//
//  Created by kairu on 16/8/25.
//  Copyright © 2016年 kairu. All rights reserved.
//

#import "TJHomeBookSerVer.h"
#import "MJExtension.h"
#import "KRStudentListModel.h"

@interface TJHomeBookSerVer ()

/// 请求参数.
@property (nonatomic, strong) NSMutableDictionary *studentListParame;

@end

@implementation TJHomeBookSerVer

#pragma mark - 获取学生列表请求.
/// 请求参数.
-(NSMutableDictionary *)studentListParame{
    
    if (!_studentListParame) {
        _studentListParame = [NSMutableDictionary dictionaryWithDictionary:@{@"access_token":@"6acd2005bb519dfb4d5f9e0d3cb6d760",
                                                                             @"open_id":@"7x38fH7tPcmuQ3qhPJKd9KFv0cNFkc6TMymkt2r6JyhqOcNpTemmQyMY1",
                                                                             @"method":@"GET",
                                                                             @"class_id":@"32514",
                                                                             @"pageSizes":@"10",
                                                                             @"page":@"1"}];
    }
    
    return _studentListParame;
}

/// 请求方法.
+(void)requestForStudentListWithPage:(NSString *)page {
    
    TJHomeBookSerVer *server = [[self alloc] init];
    [server.studentListParame setValue:page forKey:@"page"];
    [[KRAFManager shareBaseAFManager] Post:@"get_student" parameters:server.studentListParame progress:nil success:^(BOOL sucessful, id objc) {
        if (sucessful && TJHomeBookSerVer.successBlock) {
            // 可在此解析数据...
            NSMutableArray *students = [NSMutableArray array];
            if ([objc isKindOfClass:[NSArray class]]) {
                for (NSDictionary *dic in objc) {
                    
                    /// 用MJExtension解析.
                    [students addObject:[KRStudentListModel mj_objectWithKeyValues:dic]];
                }
            }
            /// 回调数据.
            TJHomeBookSerVer.successBlock(students);
        }
    } message:^(BOOL sucessful, id objc) {
        if (TJHomeBookSerVer.messageInfo) {
            TJHomeBookSerVer.messageInfo(objc);
        }
    } failure:^(BOOL sucessful, id objc) {
        if (TJHomeBookSerVer.failureBlock) {
            TJHomeBookSerVer.failureBlock(objc);
        }
    }];
    
}

- (void)dealloc {
    
    NSLog(@"TJHomeBookSerVer挂了");
}

@end
