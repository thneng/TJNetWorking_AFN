//
//  NSObject+Log.h
//  02-iOS8
//
//  Created by pkxing on 14/12/7.
//  Copyright (c) 2014年 梦醒. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface NSObject (SafeAndLog)

@end
@interface NSArray (SafeAndLog)

//安全
- (id)mdf_safeObjectAtIndex:(NSUInteger)index;

@end

@interface NSDictionary (SafeAndLog)

@end


