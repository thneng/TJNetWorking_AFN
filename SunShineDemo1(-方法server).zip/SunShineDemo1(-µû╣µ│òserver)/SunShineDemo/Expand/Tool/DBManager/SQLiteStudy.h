//
//  SQLiteStudy.h
//  FMDB的二次封装
//
//  Created by baoshan on 16/9/7.
//
//

#import <Foundation/Foundation.h>

@interface SQLiteStudy : NSObject

- (void)createConstraintTable;

@end
