//
//  TJRequestModel.h
//  网络封装Demo
//
//  Created by kairu on 16/8/25.
//  Copyright © 2016年 kairu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KRAFManager.h"
#import "KRBaseServer.h"

/**
 *  专门用于做请求的model,需要从界面中获取的请求参数,实时改变的请求参数可以设置为requestForStudentList的参数,从控制器中传进来.
 */
@interface TJHomeBookSerVer : KRBaseServer

#pragma mark - 获取学生列表请求.
/// 请求参数.
@property (nonatomic, strong) NSMutableDictionary *studentListParame;
/// 请求方法.
-(void)requestForStudentList;


@end
