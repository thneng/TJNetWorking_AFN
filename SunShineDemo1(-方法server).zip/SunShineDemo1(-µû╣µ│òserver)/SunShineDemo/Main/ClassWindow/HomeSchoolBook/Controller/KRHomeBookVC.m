//
//  ViewController.m
//  网络封装Demo
//
//  Created by kairu on 16/8/25.
//  Copyright © 2016年 kairu. All rights reserved.
//

#import "KRHomeBookVC.h"
#import "TJHomeBookSerVer.h"

@interface KRHomeBookVC ()

@end

@implementation KRHomeBookVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    /// 设置网络请求.
    [self setRequest];
}


/**
 *  设置网络请求.
 */
- (void)setRequest {

    /// 创建RequestModle,并赋值请求回调
    TJHomeBookSerVer *model= [[TJHomeBookSerVer alloc] init];
    [model setBlockWithSuccessBlock:^(id returnValue,NSString *type) {
        NSLog(@"%@",returnValue);
    } messageBlock:^(id returnValue,NSString *type) {
        NSLog(@"%@",returnValue);
    } failureBlock:^(id returnValue,NSString *type) {
        NSLog(@"%@",returnValue);
    }];
    
    /** 开始请求.
     *  当请求参数需要改变时候,可以把它们加到requestForStudentList的参数里面传给RequestModle,在RequestModle里面设置;
     */
    [model requestForStudentList];
    
}



@end
