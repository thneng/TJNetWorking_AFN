//
//  TJStudentListDataModel.m
//  网络封装Demo
//
//  Created by kairu on 16/8/25.
//  Copyright © 2016年 kairu. All rights reserved.
//

#import "KRStudentListModel.h"

#pragma mark - 班级下的学生列表.
@implementation KRStudentListModel


@end


