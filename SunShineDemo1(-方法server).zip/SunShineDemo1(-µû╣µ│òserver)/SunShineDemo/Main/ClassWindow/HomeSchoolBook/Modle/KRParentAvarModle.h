//
//  KRParentAvarModle.h
//  网络封装Demo
//
//  Created by kairu on 16/9/9.
//  Copyright © 2016年 kairu. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  学生家长的头像模型.
 */
@interface KRParentAvarModle : UIView
//
@property(nonatomic,strong)NSString *avatar32;
//
@property(nonatomic,strong)NSString *avatar64;
//
@property(nonatomic,strong)NSString *avatar128;
//
@property(nonatomic,strong)NSString *avatar256;
//
@property(nonatomic,strong)NSString *avatar512;
@end
